<?php
include 'config.php';
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'editor') {
    header('Location: login.php'); exit();
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $imageName = '';
    if ($title === '' || $content === '') {
        $error = 'Judul dan isi berita wajib diisi.';
    } else {
        if (!empty($_FILES['image']['name'])) {
            $f = $_FILES['image'];
            $ext = pathinfo($f['name'], PATHINFO_EXTENSION);
            $allowed = ['jpg','jpeg','png','gif'];
            if (!in_array(strtolower($ext), $allowed)) {
                $error = 'Tipe file tidak diperbolehkan. Hanya: ' . implode(', ', $allowed);
            } else {
                $imageName = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '_', $f['name']);
                move_uploaded_file($f['tmp_name'], __DIR__ . '/uploads/' . $imageName);
            }
        }
        if (!$error) {
            $stmt = $conn->prepare('INSERT INTO news (title, content, image) VALUES (?, ?, ?)');
            $stmt->bind_param('sss', $title, $content, $imageName);
            $stmt->execute();
            header('Location: dashboard.php'); exit();
        }
    }
}
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Tambah Berita</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
  <h2>Tambah Berita</h2>
  <?php if($error): ?><div class="card" style="color:red"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
  <form method="POST" enctype="multipart/form-data" class="card" style="max-width:720px">
    <input type="text" name="title" placeholder="Judul" required>
    <textarea name="content" rows="8" placeholder="Isi berita" required></textarea>
    <label>Gambar (opsional)</label>
    <input type="file" name="image" accept="image/*">
    <div style="display:flex;gap:8px">
      <button type="submit" class="cta">Simpan</button>
      <a href="dashboard.php">Batal</a>
    </div>
  </form>
</div>
</body>
</html>
