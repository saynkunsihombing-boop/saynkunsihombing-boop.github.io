<?php
include 'config.php';
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'editor') {
    header('Location: login.php');
    exit();
}
// Fetch news
$res = $conn->query('SELECT id, title, content, image, `date` FROM news ORDER BY `date` DESC');
$news = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Dashboard Editor - Yayasan Jalan Harapan Indonesia</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
  <div style="display:flex;justify-content:space-between;align-items:center">
    <h1>Dashboard Editor</h1>
    <div>
      <span style="color:var(--muted)">Login sebagai: <?php echo htmlspecialchars($_SESSION['username']); ?></span>
      <a href="logout.php" style="margin-left:12px">Logout</a>
    </div>
  </div>
  <div style="margin-top:12px">
    <a class="cta" href="add_news.php">Tambah Berita</a>
  </div>
  <hr>
  <?php if(empty($news)): ?>
    <div class="card">Belum ada berita.</div>
  <?php else: foreach($news as $n): ?>
    <div class="card" style="margin-bottom:12px;display:flex;justify-content:space-between;align-items:center">
      <div>
        <h3 style="margin:6px 0"><?php echo htmlspecialchars($n['title']); ?></h3>
        <div style="color:var(--muted);font-size:13px"><?php echo htmlspecialchars($n['date']); ?></div>
      </div>
      <div>
        <a href="edit_news.php?id=<?php echo $n['id']; ?>">Edit</a> |
        <a href="delete_news.php?id=<?php echo $n['id']; ?>" onclick="return confirm('Hapus berita ini?');">Hapus</a>
      </div>
    </div>
  <?php endforeach; endif; ?>
</div>
</body>
</html>
