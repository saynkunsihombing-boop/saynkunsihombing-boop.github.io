<?php
include 'config.php';
// Fetch latest news
$stmt = $conn->prepare("SELECT id, title, content, image, `date` FROM news ORDER BY `date` DESC LIMIT 10");
$stmt->execute();
$result = $stmt->get_result();
$news = $result->fetch_all(MYSQLI_ASSOC);
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Yayasan Jalan Harapan Indonesia</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <div class="container nav">
      <div class="brand">
        <div class="logo">JH</div>
        <div>
          <div style="font-weight:700">Yayasan Jalan Harapan</div>
          <div style="font-size:12px;color:var(--muted)">Indonesia</div>
        </div>
      </div>
      <nav>
        <ul>
          <li><a href="#home">Beranda</a></li>
          <li><a href="#about">Tentang</a></li>
          <li><a href="#programs">Program</a></li>
          <li><a href="#news">Berita</a></li>
          <li><a href="#contact">Kontak</a></li>
        </ul>
      </nav>
      <div style="display:flex;gap:10px;align-items:center">
        <a class="cta" href="login.php">Login Editor</a>
      </div>
    </div>
  </header>

  <main class="container" id="home">
    <section class="hero">
      <div style="flex:1">
        <h1>Memberi Harapan, Mengubah Hidup</h1>
        <p style="color:var(--muted)">Yayasan Jalan Harapan Indonesia berkomitmen untuk mendukung pendidikan, kesehatan, dan pemberdayaan komunitas rentan di seluruh Indonesia.</p>
        <div style="margin-top:18px;display:flex;gap:12px">
          <a class="cta" href="#programs">Lihat Program</a>
          <a href="#about" style="padding:10px 14px;border-radius:10px;background:transparent;border:1px solid #e6edf3">Tentang Kami</a>
        </div>
      </div>
      <aside style="width:360px">
        <div class="card">
          <h3 style="margin-top:0">Donasi Sekarang</h3>
          <p style="color:var(--muted)">Dukung program kami agar lebih banyak keluarga menerima bantuan.</p>
          <div style="margin-top:12px;text-align:center;color:var(--muted)">Nomor Rekening: <strong>123-456-789 (Bank Contoh)</strong></div>
        </div>
      </aside>
    </section>

    <section id="about">
      <h2>Tentang Kami</h2>
      <p>Yayasan Jalan Harapan Indonesia didirikan untuk membantu anak-anak dan keluarga yang membutuhkan melalui program pendidikan, kesehatan, serta pelatihan keterampilan.</p>
    </section>

    <section id="programs">
      <h2>Program Kami</h2>
      <div class="grid-3">
        <div class="program">
          <h3>Beasiswa Pendidikan</h3>
          <p style="color:var(--muted)">Menyediakan dukungan biaya pendidikan untuk siswa pra-sejahtera.</p>
        </div>
        <div class="program">
          <h3>Klinik Keliling</h3>
          <p style="color:var(--muted)">Layanan kesehatan dasar dan imunisasi untuk anak-anak di daerah terpencil.</p>
        </div>
        <div class="program">
          <h3>Pelatihan Keterampilan</h3>
          <p style="color:var(--muted)">Pelatihan menjahit, tata boga, dan keterampilan digital untuk pemberdayaan ekonomi.</p>
        </div>
      </div>
    </section>

    <section id="news">
      <h2>Berita & Kegiatan</h2>
      <div style="display:grid;gap:12px">
        <?php if(count($news) == 0): ?>
          <div class="card">Belum ada berita. Login sebagai editor untuk menambah.</div>
        <?php else: foreach($news as $n): ?>
          <article class="card" style="display:flex;gap:12px;align-items:flex-start">
            <?php if(!empty($n['image']) && file_exists('uploads/' . $n['image'])): ?>
              <img src="uploads/<?php echo htmlspecialchars($n['image']); ?>" alt="" style="width:160px;height:100px;object-fit:cover;border-radius:8px">
            <?php endif; ?>
            <div>
              <h4 style="margin:6px 0"><?php echo htmlspecialchars($n['title']); ?></h4>
              <div style="color:var(--muted);font-size:13px;margin-bottom:8px"><?php echo htmlspecialchars(date('d M Y', strtotime($n['date']))); ?></div>
              <p style="margin:0;color:var(--muted)"><?php echo nl2br(htmlspecialchars(substr($n['content'],0,220))); ?><?php if(strlen($n['content'])>220) echo '...'; ?></p>
            </div>
          </article>
        <?php endforeach; endif; ?>
      </div>
    </section>

    <section id="contact">
      <h2>Kontak</h2>
      <div style="display:flex;gap:18px;flex-wrap:wrap">
        <div style="flex:1">
          <p>Alamat: Jl. Contoh No. 10, Jakarta</p>
          <p>Email: <a href="mailto:info@jalanharapan.or.id">info@jalanharapan.or.id</a></p>
          <p>Telepon: +62 21 555 0123</p>
        </div>
        <div style="width:360px" class="card">
          <h4>Form Kontak</h4>
          <form onsubmit="alert('Form kontak simulasi — integrasikan backend untuk menyimpan/pengiriman email.'); return false;">
            <input placeholder="Nama" required>
            <input type="email" placeholder="Email" required>
            <textarea rows="4" placeholder="Pesan" required></textarea>
            <button type="submit">Kirim Pesan</button>
          </form>
        </div>
      </div>
    </section>
  </main>

  <footer>
    <div class="container">
      <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
        <div>© <strong>Yayasan Jalan Harapan Indonesia</strong></div>
        <div style="color:var(--muted)">Terdaftar & transparan. Laporan tahunan tersedia atas permintaan.</div>
      </div>
    </div>
  </footer>
</body>
</html>
